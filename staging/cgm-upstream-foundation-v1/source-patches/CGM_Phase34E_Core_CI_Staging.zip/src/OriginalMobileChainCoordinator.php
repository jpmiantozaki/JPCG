<?php
declare(strict_types=1);
namespace CGM\Phase34E;

require_once __DIR__ . '/GenerationBoundRelayLedger.php';
require_once __DIR__ . '/ProviderHandoffGate.php';

use CGM\Phase34D\GenerationBoundRelayLedger;
use CGM\Phase40CD\ProviderHandoffGate;

/**
 * OFFLINE / STAGING original-mobile acceptance-chain readiness coordinator.
 *
 * This combines previously built local callback generation binding with
 * the existing server-owned provider admission policy. Native handler markers
 * are only local observations and are NEVER accepted as provider evidence.
 * No APK integration, live login, game packet or session issuance is provided.
 * A trusted official provider verifier is an external, currently UNCONFIGURED
 * dependency. Never reinterpret a third-party VIP rejection as success.
 */
final class OriginalMobileChainCoordinator
{
    private const EVENTS = [
        'LOGIN_ZERO_RESULT', 'VERIFY_CCU_ACCEPTED', 'GAME_ZERO_RESULT',
        'USER_INFO_HANDLER_OBSERVED', 'CHANNEL_TO_GARDEN',
        'GARDEN_LOGIN_ZERO_RESULT', 'GARDEN_LOAD_ZERO_RESULT',
    ];
    private const EVENT_SERVICE = [
        'LOGIN', 'GAME', 'GAME', 'GAME', 'GAME', 'GARDEN', 'GARDEN',
    ];
    private array $attempts = [];

    public function __construct(
        private GenerationBoundRelayLedger $callbacks,
        private ProviderHandoffGate $providerGate,
    ) {}

    public function begin(int $now, int $ttlSeconds = 90): ?string
    {
        $id = $this->callbacks->begin($now, $ttlSeconds);
        if ($id === null) return null;
        $this->attempts[$id] = [
            'expires' => $now + $ttlSeconds,
            'active' => true,
            'finalized' => false,
            'next' => 0,
            'stage0_callback_correlated' => false,
            'stage1_callback_correlated' => false,
            'last_observed_at' => 0,
            'sockets' => [
                'LOGIN' => ['generation' => 0, 'open' => false],
                'GAME' => ['generation' => 0, 'open' => false],
                'GARDEN' => ['generation' => 0, 'open' => false],
            ],
        ];
        return $id;
    }

    /** Local socket generation only. Returns null on forbidden transitions. */
    public function openSocket(string $attemptId, string $service, int $now): ?int
    {
        if (!$this->active($attemptId, $now)
            || !in_array($service, ['LOGIN', 'GAME', 'GARDEN'], true)) return null;
        $a = &$this->attempts[$attemptId];
        if ($service === 'GAME' && ($a['next'] < 1 || !$a['stage0_callback_correlated'])) return null;
        if ($service === 'GARDEN' && ($a['next'] < 5 || !$a['stage1_callback_correlated'])) return null;
        if ($service === 'LOGIN') {
            $generation = $this->callbacks->openSocket($attemptId, 'LOGIN', $now);
            if ($generation === null) return null;
            // Reopening LOGIN invalidates the complete old native sequence.
            if ($a['sockets']['LOGIN']['generation'] > 0) {
                $a['next'] = 0;
                $a['stage0_callback_correlated'] = false;
                $a['stage1_callback_correlated'] = false;
                $a['sockets']['GAME']['open'] = false;
                $a['sockets']['GARDEN']['open'] = false;
                $this->callbacks->closeSocket($attemptId, 'GAME');
            }
        } elseif ($service === 'GAME') {
            $generation = $this->callbacks->openSocket($attemptId, 'GAME', $now);
            if ($generation === null) return null;
            $a['next'] = 1;
            $a['stage1_callback_correlated'] = false;
            $a['sockets']['GARDEN']['open'] = false;
        } else {
            $old = $a['sockets']['GARDEN']['generation'];
            if ($old >= PHP_INT_MAX) return null;
            $generation = $old + 1;
            $a['next'] = 5;
        }
        $a['sockets'][$service] = ['generation' => $generation, 'open' => true];
        return $generation;
    }

    public function closeSocket(string $attemptId, string $service): bool
    {
        if (!isset($this->attempts[$attemptId])
            || !in_array($service, ['LOGIN', 'GAME', 'GARDEN'], true)) return false;
        $a = &$this->attempts[$attemptId];
        $a['sockets'][$service]['open'] = false;
        if ($service !== 'GARDEN') $this->callbacks->closeSocket($attemptId, $service);
        // The original LoginServer normally disconnects AFTER successful
        // handoff. Allow that one historical transition, not an early close.
        if ($service === 'LOGIN' && $a['next'] >= 1) return true;
        // Losing GameServer/Garden before final evaluation invalidates the
        // entire readiness attempt. It does not revoke a real provider token.
        $this->cancel($attemptId);
        return true;
    }

    /** Returns ONLY a locally generated callback ID and its socket generation. */
    public function enqueueRelay(string $attemptId, int $stage, int $now): ?array
    {
        if (!$this->active($attemptId, $now) || !in_array($stage, [0, 1], true)) return null;
        $a = $this->attempts[$attemptId];
        if (($stage === 0 && $a['next'] > 0)
            || ($stage === 1 && ($a['next'] < 1 || !$a['stage0_callback_correlated']))) return null;
        $service = $stage === 0 ? 'LOGIN' : 'GAME';
        if (!$a['sockets'][$service]['open']) return null;
        return $this->callbacks->enqueue($attemptId, $stage, $service, $now);
    }

    /** Neither a matching response nor a rejected response proves game auth. */
    public function deliverRelay(
        string $requestId, string $attemptId, int $stage,
        string $service, int $generation, int $now,
    ): array {
        $verdict = $this->callbacks->deliver(
            $requestId, $attemptId, $stage, $service, $generation, $now
        );
        if ($verdict['local_callback_correlated'] === true
            && $this->active($attemptId, $now)
            && $this->attempts[$attemptId]['sockets'][$service]['open']
            && $this->attempts[$attemptId]['sockets'][$service]['generation'] === $generation) {
            $key = $stage === 0 ? 'stage0_callback_correlated' : 'stage1_callback_correlated';
            $this->attempts[$attemptId][$key] = true;
        }
        return $verdict;
    }

    /**
     * A declared local native-handler event. It is NOT independently verified
     * as a genuine server-origin reply and cannot grant official authorization.
     * Consumer MUST NOT feed untrusted event JSON into a provider verifier.
     */
    public function observeNativeMarker(
        string $attemptId, string $event, string $service,
        int $generation, int $now,
    ): array {
        if (!$this->active($attemptId, $now)) return self::marker('ATTEMPT_NOT_ACTIVE');
        $a = &$this->attempts[$attemptId];
        $i = $a['next'];
        if ($i >= count(self::EVENTS)) return self::marker('SEQUENCE_ALREADY_RECORDED');
        if ($event !== self::EVENTS[$i] || $service !== self::EVENT_SERVICE[$i]) {
            return self::marker('UNEXPECTED_EVENT_OR_SERVICE');
        }
        if ($now < $a['last_observed_at']) return self::marker('EVENT_TIME_REGRESSION');
        if (!$a['sockets'][$service]['open']
            || $a['sockets'][$service]['generation'] !== $generation || $generation < 1) {
            return self::marker('STALE_SOCKET_GENERATION');
        }
        if ($i === 0 && !$a['stage0_callback_correlated']) {
            return self::marker('STAGE0_NOT_CORRELATED');
        }
        if ($i >= 1 && !$a['stage1_callback_correlated']) {
            return self::marker('STAGE1_NOT_CORRELATED');
        }
        $a['next']++;
        $a['last_observed_at'] = $now;
        return self::marker('LOCAL_NATIVE_MARKER_RECORDED', true);
    }

    /**
     * This can only attest admission preconditions via the separate trusted
     * provider policy. It NEVER creates/returns a PlayPark or Garden session.
     * The provider verifier and link store are unconfigured in shipped code.
     */
    public function finalize(
        string $attemptId, string $claimedEmail,
        string $opaqueProviderProof, int $now,
    ): array {
        if (!$this->active($attemptId, $now)) return self::decision('ATTEMPT_INACTIVE');
        $a = &$this->attempts[$attemptId];
        if ($a['next'] !== count(self::EVENTS)
            || !$a['stage0_callback_correlated']
            || !$a['stage1_callback_correlated']
            || !$a['sockets']['GAME']['open']
            || !$a['sockets']['GARDEN']['open']) {
            return self::decision('LOCAL_CHAIN_INCOMPLETE');
        }
        $a['finalized'] = true;
        $gate = $this->providerGate->evaluate($claimedEmail, $opaqueProviderProof, $attemptId, $now);
        $this->callbacks->cancel($attemptId);
        return self::decision((string) ($gate['reason'] ?? 'PROVIDER_NOT_VERIFIED'),
            ($gate['decision'] ?? null) === 'PRECONDITIONS_ATTESTED_ONLY');
    }

    /** No account ID, proof, session, packet or internal request IDs. */
    public function status(string $attemptId, int $now): array
    {
        $a = $this->attempts[$attemptId] ?? null;
        if (!is_array($a)) return ['classification' => 'UNKNOWN_ATTEMPT', 'events_observed' => 0];
        return [
            'classification' => $a['finalized'] ? 'EVALUATED_POLICY_ONLY'
                : ($this->active($attemptId, $now) ? 'LOCAL_OBSERVATION_IN_PROGRESS' : 'INACTIVE'),
            'events_observed' => $a['next'],
            'expected_events' => count(self::EVENTS),
            'stage0_callback_correlated' => $a['stage0_callback_correlated'],
            'stage1_callback_correlated' => $a['stage1_callback_correlated'],
            'original_provider_authenticated' => false,
            'game_session_issued' => false,
        ];
    }

    public function cancel(string $attemptId): void
    {
        if (isset($this->attempts[$attemptId])) $this->attempts[$attemptId]['active'] = false;
        $this->callbacks->cancel($attemptId);
    }

    private function active(string $attemptId, int $now): bool
    {
        $a = $this->attempts[$attemptId] ?? null;
        return is_array($a) && $a['active'] === true && !$a['finalized']
            && $now > 0 && $a['expires'] > $now;
    }

    private static function marker(string $label, bool $observed = false): array
    {
        return [
            'classification' => $label,
            'locally_observed' => $observed,
            'official_origin_verified' => false,
            'game_session_issued' => false,
        ];
    }

    private static function decision(string $reason, bool $attested = false): array
    {
        return [
            'scope' => 'CGM_PHASE34E_CHAIN_READINESS_ONLY',
            'decision' => $attested ? 'PROVIDER_POLICY_PRECONDITIONS_ATTESTED_ONLY' : 'DENIED',
            'reason' => $reason,
            'session_issued' => false,
            'game_packet_generated' => false,
            'garden_authorized_by_cgm' => false,
        ];
    }
}
