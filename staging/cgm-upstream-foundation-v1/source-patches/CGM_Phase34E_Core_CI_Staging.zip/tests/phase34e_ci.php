<?php
declare(strict_types=1);
require_once __DIR__.'/../src/OriginalMobileChainCoordinator.php';
use CGM\Phase34E\OriginalMobileChainCoordinator;
use CGM\Phase34D\GenerationBoundRelayLedger;
use CGM\Phase40CD\ProviderHandoffGate;
use CGM\Phase40CD\UnconfiguredProviderVerifier;
use CGM\Phase40CD\UnconfiguredAccountLinkRepository;
use CGM\Phase40CD\UnconfiguredMembershipRepository;
use CGM\Phase40CD\DenyOnlyAttemptStore;
$checks=0;
function ck(bool $x):void{global $checks;if(!$x)throw new RuntimeException('phase34e invariant failed');++$checks;}
$c=new OriginalMobileChainCoordinator(new GenerationBoundRelayLedger(),
    new ProviderHandoffGate(new UnconfiguredProviderVerifier(),
        new UnconfiguredAccountLinkRepository(),new UnconfiguredMembershipRepository(),
        new DenyOnlyAttemptStore(),'cgm-upstream-garden-v1'));
$t=30000;$a=$c->begin($t);
ck(is_string($a));
ck($c->openSocket($a,'GAME',$t)===null);
ck($c->openSocket($a,'LOGIN',$t)===1);
$r=$c->enqueueRelay($a,0,$t);ck(is_array($r));
ck(!$c->deliverRelay($r['request_id'],$a,0,'LOGIN',99,$t+1)['local_callback_correlated']);
ck($c->deliverRelay($r['request_id'],$a,0,'LOGIN',1,$t+1)['local_callback_correlated']);
ck($c->observeNativeMarker($a,'LOGIN_ZERO_RESULT','LOGIN',1,$t+2)['locally_observed']);
ck($c->closeSocket($a,'LOGIN'));
ck($c->openSocket($a,'GAME',$t+3)===1);
$e=$c->enqueueRelay($a,1,$t+4);ck(is_array($e));
ck($c->deliverRelay($e['request_id'],$a,1,'GAME',1,$t+5)['local_callback_correlated']);
foreach(['VERIFY_CCU_ACCEPTED','GAME_ZERO_RESULT','USER_INFO_HANDLER_OBSERVED',
         'CHANNEL_TO_GARDEN'] as $i=>$event){ck($c->observeNativeMarker($a,$event,'GAME',1,$t+6+$i)['locally_observed']);}
ck($c->openSocket($a,'GARDEN',$t+10)===1);
ck($c->observeNativeMarker($a,'GARDEN_LOGIN_ZERO_RESULT','GARDEN',1,$t+11)['locally_observed']);
ck($c->observeNativeMarker($a,'GARDEN_LOAD_ZERO_RESULT','GARDEN',1,$t+12)['locally_observed']);
ck($c->status($a,$t+13)['events_observed']===7);
$d=$c->finalize($a,'synthetic@example.test','not-a-real-provider-proof',$t+14);
ck($d['decision']==='DENIED');
ck($d['reason']==='PROVIDER_UNCONFIGURED_OR_UNVERIFIED');
ck($d['session_issued']===false&&!$d['garden_authorized_by_cgm']);
ck($c->finalize($a,'synthetic@example.test','not-a-real-provider-proof',$t+15)['reason']==='ATTEMPT_INACTIVE');
for($i=0;$i<100;$i++){
    $ts=40000+100*$i;$id=$c->begin($ts);$c->openSocket($id,'LOGIN',$ts);
    $p=$c->enqueueRelay($id,0,$ts);
    $v=$c->deliverRelay($p['request_id'],$id,0,'LOGIN',1,$ts);
    ck($v['local_callback_correlated']);
    ck(!$v['official_game_authenticated']);
    ck($c->finalize($id,'synthetic@example.test','fake',$ts)['decision']==='DENIED');
}
echo "PHASE34E_CI_PASS assertions=$checks (OFFLINE SYNTHETIC ONLY)\n";
